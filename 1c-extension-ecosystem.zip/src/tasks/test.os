// src/tasks/test.os - Запуск тестов расширения
// OneScript v2.0.1
// Запуск: tools\oscript\oscript.exe src\tasks\test.os
//         tools\oscript\oscript.exe src\tasks\test.os syntax
//         tools\oscript\oscript.exe src\tasks\test.os xunit
//         tools\oscript\oscript.exe src\tasks\test.os bdd

Перем ТипТестов;

Процедура ЗапуститьТесты(Знач Тип)
    Если Тип = "syntax" Тогда
        Сообщить("Синтаксический контроль через BSL LS...");
        // TODO: вызов tools/bsl-ls.jar --analyze --srcDir src/cfe
    ИначеЕсли Тип = "xunit" Тогда
        Сообщить("Запуск xUnit тестов...");
        // TODO: вызов xUnitFor1C в пакетном режиме
    ИначеЕсли Тип = "bdd" Тогда
        Сообщить("Запуск Vanessa BDD сценариев...");
        // TODO: features/ -> Vanessa-Automation
    Иначе
        Сообщить("Неизвестный тип тестов: " + Тип);
        Сообщить("Доступные: syntax | xunit | bdd");
    КонецЕсли;
КонецПроцедуры

// -- Точка входа --
// АргументыКоманднойСтроки - свойство (не функция!) в OneScript v2
ТипТестов = "syntax";
Аргументы = АргументыКоманднойСтроки;
Если Аргументы.Количество() > 0 Тогда
    ТипТестов = Аргументы[0];
КонецЕсли;

ЗапуститьТесты(ТипТестов);
