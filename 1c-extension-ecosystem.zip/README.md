# 1C Extension Ecosystem Template

Шаблон экосистемы разработки расширений 1С:Предприятие 8.3.

VS Code + Claude Code как парный программист + GitHub/GitLab CI.

## Архитектура

```
1c-extension-ecosystem/     ← репозиторий шаблона (этот)
├── CLAUDE.md, GOALS.md...  ← артефакты PM и экосистемы
├── tools/                  ← портативные инструменты
├── scripts/                ← AI review для CI
├── .github/ / .gitlab-ci.yml
│
└── src/                    ← проект 1C: Platform Tools
    ├── packagedef           ← активирует расширение VS Code
    ├── env.json             ← подключение к ИБ
    ├── cf/                  ← исходники конфигурации (обязательно)
    ├── cfe/                 ← исходники расширения (обязательно)
    ├── epf/ erf/            ← обработки и отчёты (опционально)
    ├── tasks/               ← OScript задачи
    ├── features/            ← Vanessa BDD
    └── build/               ← ИБ и результаты сборки
```

## Подключение src/

`src/` содержит проект 1C: Platform Tools. PM определяет структуру автоматически
при инициализации — анализирует наличие `.git`, junction и исходников.

Возможные варианты размещения:

- **Встроенная папка** — src/ входит в репозиторий экосистемы напрямую
- **Git submodule** — src/ подключён как отдельный репозиторий (`git submodule add <url> src`)
- **Junction** — src/ ссылается на внешний репозиторий (`New-Item -ItemType Junction -Path src -Target <путь>`)

## Стек

| Слой | Инструменты |
|------|-------------|
| IDE | VS Code + [1C: Platform Extension Pack](https://marketplace.visualstudio.com/items?itemName=yellow-hammer.1c-platform-extension-pack) |
| AI агент | Claude Code + [cc-1c-skills](https://github.com/Nikolay-Shirokov/cc-1c-skills) + [claude-code-skills-1c](https://github.com/Desko77/claude-code-skills-1c) |
| PM | Claude (CLAUDE.md / GOALS.md / TODO.md / ADR.md) |
| CI/CD | GitHub Actions / GitLab CI |

## Быстрый старт

### Способ A — из GitHub (если есть доступ к репозиторию шаблона)

```
GitHub → "Use this template" → Create new repository → клонировать
```

### Способ Б — из ZIP-архива (если нет доступа к репозиторию)

1. Скачать ZIP из [1c-extension-ecosystem-dist](https://github.com/d-n-komarov/1c-extension-ecosystem-dist) или получить у владельца
2. Распаковать в папку проекта
3. Создать репозиторий на GitHub/GitLab:
   - GitHub: [github.com/new](https://github.com/new) → имя → Private → **без README** → Create
   - GitLab: New project → Create blank project → **без README** → Create
   - Скопировать URL репозитория
4. Инициализировать git:
   ```powershell
   cd <папка-проекта>
   git init
   git branch -m production
   git add .
   git commit -m "feat: init from 1c-extension-ecosystem template"
   ```
   Если используете git-хостинг (GitHub, GitLab и др.) — опционально:
   ```powershell
   git remote add origin <url-репозитория>
   git push -u origin production
   ```

### Способ В — клонирование и очистка истории

```powershell
git clone <url-шаблона> <имя-проекта>
cd <имя-проекта>
git remote remove origin
```

Если используете git-хостинг — опционально создать репозиторий и подключить:

```powershell
git branch -m production
git remote add origin <url-нового-репозитория>
git push -u origin production
```

---

### Общие шаги после любого способа старта

1. Разместить src/ (встроенная папка, submodule или junction — по ситуации)
2. Открыть VS Code — 1C: Platform Tools активируется при наличии `src/packagedef`
3. Установить инструменты PM — открыть **PowerShell** из папки проекта и выполнить:
   ```powershell
   powershell -ExecutionPolicy Bypass -File tools/get-tools.ps1
   ```
4. Настроить `src/env.json`:
   ```json
   { "default": { "--ibconnection": "/F./build/ib" } }
   ```
5. Запустить Claude Code:
   ```powershell
   claude --dangerously-skip-permissions
   ```
   > ⚠️ Флаг `--dangerously-skip-permissions` обязателен — без него Claude Code
   > будет запрашивать подтверждение на каждую операцию с файлами.
   > `bypassPermissions` в `.claude/settings.json` не работает в Claude Code v2.1.53+.
6. Сказать Claude: _"Прочитай CLAUDE.md и начни инициализацию проекта"_
7. Заполнить `GOALS.md` (заказчик) → Claude создаёт `TODO.md`

## Настройка токенов

Токены хранятся в файле `.env` (не коммитится — уже в `.gitignore`):

```powershell
# Скопировать шаблон
Copy-Item .env.example .env
# Открыть и заполнить реальными значениями
code .env
```

### Токены

| Токен | Зачем | Обязателен |
|-------|-------|-----------|
| `ANTHROPIC_API_KEY` | AI review в CI/CD | Нет (можно отключить в ci.yml) |
| `GITHUB_PERSONAL_ACCESS_TOKEN` | Доступ к GitHub API через MCP | Только при работе с GitHub |

**ANTHROPIC_API_KEY:**
[console.anthropic.com](https://console.anthropic.com) → API Keys → Create Key

**GITHUB_PERSONAL_ACCESS_TOKEN:**
GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)

| Scope | Зачем |
|-------|-------|
| `repo` | Чтение и запись репозитория (issues, PR, код) |
| `workflow` | Обновление файлов GitHub Actions workflows |

> PM запросит заполнить `.env` при инициализации проекта.

## Ссылки

| Ресурс | URL |
|--------|-----|
| 1C: Platform Extension Pack | https://marketplace.visualstudio.com/items?itemName=yellow-hammer.1c-platform-extension-pack |
| 1C: Platform Tools | https://marketplace.visualstudio.com/items?itemName=yellow-hammer.1c-platform-tools |
| vanessa-bootstrap | https://github.com/yellow-hammer/vanessa-bootstrap |
| cc-1c-skills | https://github.com/Nikolay-Shirokov/cc-1c-skills |
| claude-code-skills-1c | https://github.com/Desko77/claude-code-skills-1c |

## Лицензия

MIT
