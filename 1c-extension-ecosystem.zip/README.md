# 1C Extension Ecosystem Template

Шаблон экосистемы разработки расширений 1С:Предприятие 8.3.

VS Code + Claude Code как парный программист + GitHub/GitLab CI.

## Архитектура

```
1c-extension-ecosystem/     ← репозиторий шаблона (этот)
├── CLAUDE.md, GOALS.md...  ← артефакты PM и экосистемы
├── tools/                  ← портативные инструменты
├── scripts/                ← AI review для CI
├── .github/ / .gitlab-ci.yml
│
└── src/                    ← проект 1C: Platform Tools
    ├── packagedef           ← активирует расширение VS Code
    ├── env.json             ← подключение к ИБ
    ├── cfe/                 ← исходники расширения
    ├── epf/ erf/            ← обработки и отчёты
    ├── tasks/               ← OScript задачи
    ├── features/            ← Vanessa BDD
    └── build/               ← ИБ и результаты сборки
```

## Варианты подключения src/

**A — встроенная папка** (всё в одном репозитории):
`src/` входит в шаблон. Проект и экосистема в одном git-репо.

**Б — git submodule** (раздельные репозитории):
```bash
git submodule add <url-проекта-1С> src
git submodule update --init
```
Один проект 1С — несколько конфигураций экосистемы.

**В — только src/** как самостоятельный репозиторий:
VS Code открывает `src/` напрямую. Экосистема — в родительской папке.

## Стек

| Слой | Инструменты |
|------|-------------|
| IDE | VS Code + [1C: Platform Extension Pack](https://marketplace.visualstudio.com/items?itemName=yellow-hammer.1c-platform-extension-pack) |
| AI агент | Claude Code + [cc-1c-skills](https://github.com/Nikolay-Shirokov/cc-1c-skills) + [claude-code-skills-1c](https://github.com/Desko77/claude-code-skills-1c) |
| PM | Claude (CLAUDE.md / GOALS.md / TODO.md / ADR.md) |
| CI/CD | GitHub Actions / GitLab CI |

## Быстрый старт

### Способ A — из GitHub (если есть доступ к репозиторию шаблона)

```
GitHub → "Use this template" → Create new repository → клонировать
```

### Способ Б — из ZIP-архива (если нет доступа к репозиторию)

1. Скачать архив шаблона у владельца или из артефактов CI
2. Распаковать в нужную папку
3. Инициализировать git:
   ```powershell
   cd <папка-проекта>
   git init
   git add .
   git commit -m "feat: init from 1c-extension-ecosystem template"
   ```
4. Подключить удалённый репозиторий (GitHub, GitLab или корпоративный):
   ```powershell
   git remote add origin <url-вашего-репозитория>
   git push -u origin main
   ```

### Способ В — клонирование и очистка истории

```powershell
git clone <url-шаблона> <имя-проекта>
cd <имя-проекта>
git remote remove origin
git remote add origin <url-вашего-репозитория>
git push -u origin main
```

---

### Общие шаги после любого способа старта

1. Выбрать вариант подключения `src/` (A / Б / В — см. раздел выше)
2. Открыть VS Code — 1C: Platform Tools активируется при наличии `src/packagedef`
3. Установить инструменты PM:
   ```powershell
   pwsh -ExecutionPolicy Bypass -File tools/get-tools.ps1
   ```
4. Настроить `src/env.json`:
   ```json
   { "default": { "--ibconnection": "/F./build/ib" } }
   ```
5. Сказать Claude Code: _"Прочитай CLAUDE.md, действуй как PM, заполни среду разработки"_
6. Заполнить `GOALS.md` (заказчик) → Claude создаёт `TODO.md`

## Интеграция существующего расширения

См. [INTEGRATE.md](./INTEGRATE.md)

## Ссылки

| Ресурс | URL |
|--------|-----|
| 1C: Platform Extension Pack | https://marketplace.visualstudio.com/items?itemName=yellow-hammer.1c-platform-extension-pack |
| 1C: Platform Tools | https://marketplace.visualstudio.com/items?itemName=yellow-hammer.1c-platform-tools |
| vanessa-bootstrap | https://github.com/yellow-hammer/vanessa-bootstrap |
| cc-1c-skills | https://github.com/Nikolay-Shirokov/cc-1c-skills |
| claude-code-skills-1c | https://github.com/Desko77/claude-code-skills-1c |

## Лицензия

MIT
