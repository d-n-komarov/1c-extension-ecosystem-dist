# tools/get-tools.ps1
# Auto-install portable PM tools into tools/ (no admin rights required)
#
# Pinned versions (tested with 1C Extension Ecosystem v1.0):
#   Python      3.12.10
#   OneScript   2.0.1
#   BSL LS      0.29.0
#   Temurin JRE 21.0.11+10 (LTS)
#
# Usage (from project folder):
#   powershell -ExecutionPolicy Bypass -File tools/get-tools.ps1
#   powershell -ExecutionPolicy Bypass -File tools/get-tools.ps1 -Tool python
#   powershell -ExecutionPolicy Bypass -File tools/get-tools.ps1 -Tool skills -ProjectDir <path-to-src>
#
# Tools: python | oscript | bsl-ls | skills | all
# Log:   tools/logs/get-tools.log

param(
    [string]$Tool = "all",
    [string]$ProjectDir = ""
)

$ErrorActionPreference = "Stop"
$ToolsDir = $PSScriptRoot
$Headers  = @{ "User-Agent" = "1c-extension-ecosystem/get-tools" }
$LogDir   = Join-Path $ToolsDir "logs"
$LogFile  = Join-Path $LogDir "get-tools.log"

# -- Pinned versions --------------------------------------------------
$V_PYTHON   = "3.12.10"
$V_OSCRIPT  = "2.0.1"
$V_BSLLS    = "0.29.0"
$V_JRE      = "21.0.11+10"

# -- Pinned download URLs ---------------------------------------------
$URL_PYTHON  = "https://www.python.org/ftp/python/$V_PYTHON/python-$V_PYTHON-embed-amd64.zip"
$URL_OSCRIPT = "https://github.com/EvilBeaver/OneScript/releases/download/v$V_OSCRIPT/OneScript-$V_OSCRIPT-win-x64.zip"
$URL_BSLLS   = "https://github.com/1c-syntax/bsl-language-server/releases/download/v$V_BSLLS/bsl-language-server-$V_BSLLS-exec.jar"
$URL_JRE     = "https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.11%2B10/OpenJDK21U-jre_x64_windows_hotspot_21.0.11_10.zip"

# -- Skills ZIP URLs (main branch) ------------------------------------
$URL_SHIROKOV_ZIP = "https://github.com/Nikolay-Shirokov/cc-1c-skills/archive/refs/heads/main.zip"
$URL_DESKO_ZIP    = "https://github.com/Desko77/claude-code-skills-1c/archive/refs/heads/main.zip"

# -- Logging ----------------------------------------------------------

function Write-Log([string]$Level, [string]$Msg) {
    $Stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $Line  = "[$Stamp] [$Level] $Msg"
    switch ($Level) {
        "INFO"  { Write-Host "  $Msg" -ForegroundColor Gray }
        "OK"    { Write-Host "  OK: $Msg" -ForegroundColor Green }
        "SKIP"  { Write-Host "  SKIP: $Msg (already installed)" -ForegroundColor Gray }
        "STEP"  { Write-Host ""; Write-Host "> $Msg" -ForegroundColor Cyan }
        "ERROR" { Write-Host "  ERROR: $Msg" -ForegroundColor Red }
    }
    try {
        if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory $LogDir -Force | Out-Null }
        Add-Content -Path $LogFile -Value $Line -Encoding UTF8
    } catch { }
}

function Write-Step([string]$Msg)     { Write-Log "STEP"  $Msg }
function Write-OK([string]$Msg)       { Write-Log "OK"    $Msg }
function Write-Skip([string]$Msg)     { Write-Log "SKIP"  $Msg }
function Write-LogError([string]$Msg) { Write-Log "ERROR" $Msg }

function Download-File([string]$Url, [string]$OutPath) {
    Write-Log "INFO" "Downloading: $Url"
    try {
        Invoke-WebRequest -Uri $Url -OutFile $OutPath -Headers $Headers -TimeoutSec 120
    } catch {
        Write-LogError "Download failed: $Url - $_"
        throw
    }
}

function Expand-ZipTo([string]$ZipPath, [string]$Dest) {
    if (Test-Path $Dest) { Remove-Item $Dest -Recurse -Force }
    Expand-Archive -Path $ZipPath -DestinationPath $Dest -Force
}

# ==================================================================
# TOOL 1: Python 3.12 embeddable
# ==================================================================
function Install-Python {
    Write-Step "Python $V_PYTHON embeddable"

    $PythonDir = Join-Path $ToolsDir "python"
    $PythonExe = Join-Path $PythonDir "python.exe"

    if (-not (Test-Path $PythonExe)) {
        $ZipPath = Join-Path $env:TEMP "python-embed.zip"
        Download-File $URL_PYTHON $ZipPath
        Expand-ZipTo $ZipPath $PythonDir
        Remove-Item $ZipPath -Force

        # Enable pip: uncomment 'import site' in ._pth file
        $PthFile = Get-ChildItem $PythonDir -Filter "python*._pth" | Select-Object -First 1
        if ($PthFile) {
            $Lines = Get-Content $PthFile.FullName
            $Lines = $Lines | ForEach-Object { $_ -replace "^#import site", "import site" }
            Set-Content -Path $PthFile.FullName -Value $Lines
        }

        Write-Log "INFO" "Installing pip..."
        $GetPipPath = Join-Path $env:TEMP "get-pip.py"
        Download-File "https://bootstrap.pypa.io/get-pip.py" $GetPipPath
        & $PythonExe $GetPipPath --no-warn-script-location --quiet
        Remove-Item $GetPipPath -Force

        Write-OK "Python $V_PYTHON -> tools/python/"
    } else {
        Write-Skip "tools/python/python.exe"
    }

    $PythonExe = Join-Path $PythonDir "python.exe"

    # Verify pip
    $PipTest = & $PythonExe -m pip --version 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-LogError "pip not working: $PipTest"
        return
    }

    # anthropic SDK
    $AntPkg = Join-Path $PythonDir "Lib\site-packages\anthropic"
    if (Test-Path $AntPkg) {
        Write-Skip "anthropic SDK"
    } else {
        Write-Log "INFO" "Installing anthropic SDK..."
        & $PythonExe -m pip install anthropic --no-warn-script-location --quiet
        if ($LASTEXITCODE -eq 0) { Write-OK "anthropic SDK installed" }
        else { Write-LogError "anthropic SDK install failed" }
    }

    # mcp-server-git
    $McpPkg = Join-Path $PythonDir "Lib\site-packages\mcp_server_git"
    if (Test-Path $McpPkg) {
        Write-Skip "mcp-server-git"
    } else {
        Write-Log "INFO" "Installing mcp-server-git..."
        & $PythonExe -m pip install mcp-server-git --no-warn-script-location --quiet
        if ($LASTEXITCODE -eq 0) { Write-OK "mcp-server-git installed" }
        else { Write-LogError "mcp-server-git install failed" }
    }
}

# ==================================================================
# TOOL 2: OneScript 2.0.1 portable
# ==================================================================
function Install-OScript {
    Write-Step "OneScript $V_OSCRIPT portable"

    $OScriptDir = Join-Path $ToolsDir "oscript"
    $OScriptExe = Join-Path $OScriptDir "oscript.exe"
    if (Test-Path $OScriptExe) { Write-Skip "tools/oscript/oscript.exe"; return }

    try {
        $ZipPath = Join-Path $env:TEMP "oscript.zip"
        Download-File $URL_OSCRIPT $ZipPath
        Expand-ZipTo $ZipPath $OScriptDir
        Remove-Item $ZipPath -Force

        # Flatten subfolder if needed
        $SubDir = Get-ChildItem $OScriptDir -Directory | Select-Object -First 1
        if ($SubDir -and (Test-Path (Join-Path $SubDir.FullName "oscript.exe"))) {
            Get-ChildItem $SubDir.FullName | Move-Item -Destination $OScriptDir -Force
            Remove-Item $SubDir.FullName -Recurse -Force
        }
        Write-OK "OneScript $V_OSCRIPT -> tools/oscript/"
    } catch {
        Write-LogError "OneScript download error: $_"
        Write-Log "INFO" "Download manually: https://github.com/EvilBeaver/OneScript/releases/tag/v$V_OSCRIPT"
    }
}

# ==================================================================
# TOOL 3: BSL Language Server + Temurin JRE 21
# ==================================================================
function Install-BslLs {
    Write-Step "BSL Language Server $V_BSLLS + Temurin JRE $V_JRE"

    $BslJar  = Join-Path $ToolsDir "bsl-ls.jar"
    $JreDir  = Join-Path $ToolsDir "jre"
    $JavaExe = Join-Path $JreDir "bin\java.exe"

    if (Test-Path $BslJar) {
        Write-Skip "tools/bsl-ls.jar"
    } else {
        try {
            Download-File $URL_BSLLS $BslJar
            Write-OK "bsl-ls.jar $V_BSLLS -> tools/"
        } catch {
            Write-LogError "BSL LS download error: $_"
        }
    }

    if (Test-Path $JavaExe) {
        Write-Skip "tools/jre/bin/java.exe"
    } else {
        try {
            Write-Log "INFO" "Downloading Temurin JRE $V_JRE..."
            $ZipPath = Join-Path $env:TEMP "temurin-jre.zip"
            Download-File $URL_JRE $ZipPath
            if (-not (Test-Path $JreDir)) { New-Item -ItemType Directory $JreDir | Out-Null }
            Expand-Archive -Path $ZipPath -DestinationPath $JreDir -Force
            Remove-Item $ZipPath -Force
            # Flatten subfolder
            $SubDir = Get-ChildItem $JreDir -Directory | Select-Object -First 1
            if ($SubDir -and (Test-Path (Join-Path $SubDir.FullName "bin\java.exe"))) {
                Get-ChildItem $SubDir.FullName | Move-Item -Destination $JreDir -Force
                Remove-Item $SubDir.FullName -Recurse -Force
            }
            Write-OK "Temurin JRE $V_JRE -> tools/jre/"
        } catch {
            Write-LogError "JRE download error: $_"
            Write-Log "INFO" "Download manually: https://adoptium.net/temurin/releases/?version=21"
        }
    }
}

# ==================================================================
# TOOL 4: Skills для проекта 1С
#   cc-1c-skills (Shirokov) → <ProjectDir>/.claude/skills/
#   claude-code-skills-1c (Desko77) → <ProjectDir>/.claude/skills|rules|commands/
#
# Вызывается PM после получения исходников cf и cfe (Шаг 7):
#   powershell -ExecutionPolicy Bypass -File tools\get-tools.ps1 -Tool skills -ProjectDir <path>
# ==================================================================
function Install-Skills {
    if (-not $ProjectDir) {
        Write-LogError "-ProjectDir не указан. Укажи путь к папке проекта 1С (src/ или другой)."
        Write-Host "  Пример: tools\get-tools.ps1 -Tool skills -ProjectDir D:\git\my-project\src" -ForegroundColor Yellow
        exit 1
    }

    $ResolvedDir = Resolve-Path $ProjectDir -ErrorAction SilentlyContinue
    if (-not $ResolvedDir) {
        Write-LogError "Папка не найдена: $ProjectDir"
        exit 1
    }
    $ProjDir = $ResolvedDir.Path
    $ClaudeDir = Join-Path $ProjDir ".claude"

    Write-Step "Skills для проекта: $ProjDir"

    # -- Shirokov: cc-1c-skills → .claude/skills/ --------------------
    Write-Step "cc-1c-skills (Shirokov) → .claude/skills/"

    $SkillsDest = Join-Path $ClaudeDir "skills"
    $TempZip    = Join-Path $env:TEMP "cc-1c-skills.zip"
    $TempDir    = Join-Path $env:TEMP "cc-1c-skills-tmp"

    try {
        Download-File $URL_SHIROKOV_ZIP $TempZip
        if (Test-Path $TempDir) { Remove-Item $TempDir -Recurse -Force }
        Expand-Archive -Path $TempZip -DestinationPath $TempDir -Force
        Remove-Item $TempZip -Force

        # GitHub ZIP содержит папку cc-1c-skills-main/
        $ExtractedRoot = Get-ChildItem $TempDir -Directory | Select-Object -First 1

        # Копируем .claude/skills/* → <ProjectDir>/.claude/skills/
        $SkillsSrc = Join-Path $ExtractedRoot.FullName ".claude\skills"
        if (Test-Path $SkillsSrc) {
            if (-not (Test-Path $SkillsDest)) { New-Item -ItemType Directory $SkillsDest -Force | Out-Null }
            Copy-Item -Path "$SkillsSrc\*" -Destination $SkillsDest -Recurse -Force
            Write-OK "cc-1c-skills → $SkillsDest"
        } else {
            Write-LogError "Не найдена папка .claude/skills/ в архиве Shirokov"
        }

        Remove-Item $TempDir -Recurse -Force
    } catch {
        Write-LogError "cc-1c-skills download error: $_"
    }

    # -- Desko77: claude-code-skills-1c → .claude/skills|rules|commands/ --
    Write-Step "claude-code-skills-1c (Desko77) → .claude/skills|rules|commands/"

    $TempZip = Join-Path $env:TEMP "cc-1c-skills-desko.zip"
    $TempDir = Join-Path $env:TEMP "cc-1c-skills-desko-tmp"

    try {
        Download-File $URL_DESKO_ZIP $TempZip
        if (Test-Path $TempDir) { Remove-Item $TempDir -Recurse -Force }
        Expand-Archive -Path $TempZip -DestinationPath $TempDir -Force
        Remove-Item $TempZip -Force

        # GitHub ZIP содержит папку claude-code-skills-1c-main/
        $ExtractedRoot = Get-ChildItem $TempDir -Directory | Select-Object -First 1

        $Mappings = @(
            @{ Src = "skills";   Dest = Join-Path $ClaudeDir "skills"   },
            @{ Src = "rules";    Dest = Join-Path $ClaudeDir "rules"    },
            @{ Src = "commands"; Dest = Join-Path $ClaudeDir "commands" }
        )

        foreach ($m in $Mappings) {
            $SrcPath = Join-Path $ExtractedRoot.FullName $m.Src
            if (Test-Path $SrcPath) {
                if (-not (Test-Path $m.Dest)) { New-Item -ItemType Directory $m.Dest -Force | Out-Null }
                Copy-Item -Path "$SrcPath\*" -Destination $m.Dest -Recurse -Force
                Write-OK "$($m.Src) → $($m.Dest)"
            }
        }

        Remove-Item $TempDir -Recurse -Force
    } catch {
        Write-LogError "claude-code-skills-1c download error: $_"
    }
}

# ==================================================================
# SUMMARY
# ==================================================================
function Show-Summary {
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor DarkGray
    Write-Host "  Tools status"                             -ForegroundColor White
    Write-Host "==========================================" -ForegroundColor DarkGray

    $Checks = @(
        @{ Name = "Python 3.12";    Path = "python\python.exe"                       },
        @{ Name = "pip";            Path = "python\Scripts\pip.exe"                  },
        @{ Name = "anthropic SDK";  Path = "python\Lib\site-packages\anthropic"      },
        @{ Name = "mcp-server-git"; Path = "python\Lib\site-packages\mcp_server_git" },
        @{ Name = "oscript.exe";    Path = "oscript\oscript.exe"                     },
        @{ Name = "bsl-ls.jar";     Path = "bsl-ls.jar"                              },
        @{ Name = "Temurin JRE 21"; Path = "jre\bin\java.exe"                        }
    )

    foreach ($c in $Checks) {
        $FullPath = Join-Path $ToolsDir $c.Path
        if (Test-Path $FullPath) {
            Write-Host ("  [OK  ] {0,-22} tools\{1}" -f $c.Name, $c.Path) -ForegroundColor Green
        } else {
            Write-Host ("  [MISS] {0,-22} tools\{1}" -f $c.Name, $c.Path) -ForegroundColor Red
        }
    }

    # Skills summary (только если -Tool skills был вызван)
    if ($ProjectDir -and (Test-Path $ProjectDir)) {
        $ResolvedDir = Resolve-Path $ProjectDir
        $ClaudeDir   = Join-Path $ResolvedDir.Path ".claude"
        Write-Host ""
        Write-Host "  Skills в проекте: $($ResolvedDir.Path)" -ForegroundColor DarkGray
        $SkillChecks = @(
            @{ Name = "cc-1c-skills";        Path = "skills" },
            @{ Name = "cc-1c rules";         Path = "rules"  },
            @{ Name = "cc-1c commands";      Path = "commands" }
        )
        foreach ($c in $SkillChecks) {
            $FullPath = Join-Path $ClaudeDir $c.Path
            if (Test-Path $FullPath) {
                Write-Host ("  [OK  ] {0,-22} .claude\{1}" -f $c.Name, $c.Path) -ForegroundColor Green
            } else {
                Write-Host ("  [MISS] {0,-22} .claude\{1}" -f $c.Name, $c.Path) -ForegroundColor Red
            }
        }
    }

    Write-Host ""
}

# ==================================================================
# ENTRY POINT
# ==================================================================
Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  1C Extension Ecosystem - get-tools.ps1"   -ForegroundColor Cyan
Write-Host "  Pinned: OS=$V_OSCRIPT  Py=$V_PYTHON  JRE=$V_JRE" -ForegroundColor DarkCyan
Write-Host "============================================" -ForegroundColor Cyan

Write-Log "INFO" "=== get-tools.ps1 started (Tool: $Tool) ==="

try {
    switch ($Tool.ToLower()) {
        "python"  { Install-Python  }
        "oscript" { Install-OScript }
        "bsl-ls"  { Install-BslLs  }
        "skills"  { Install-Skills  }
        "all" {
            Install-Python
            Install-OScript
            Install-BslLs
        }
        default {
            Write-Host "Unknown tool: $Tool" -ForegroundColor Red
            Write-Host "Available: all | python | oscript | bsl-ls | skills"
            Write-LogError "Unknown tool: $Tool"
            exit 1
        }
    }
    Write-Log "INFO" "=== get-tools.ps1 completed successfully ==="
} catch {
    Write-LogError "=== get-tools.ps1 FAILED: $_ ==="
    Write-Host ""
    Write-Host "  See log: $LogFile" -ForegroundColor Yellow
    throw
}

Show-Summary
Write-Log "INFO" "Log: $LogFile"
