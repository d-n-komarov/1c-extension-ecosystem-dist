# tools/get-tools.ps1
# Автоматическая установка всех портативных инструментов PM в папку tools/
#
# Запуск: pwsh -ExecutionPolicy Bypass -File tools/get-tools.ps1
# Запуск отдельного инструмента: pwsh -File tools/get-tools.ps1 -Tool python
#
# Устанавливаемые инструменты (все в tools/, без прав администратора):
#   python      — Python 3.12 embeddable + pip + пакеты (saby v8unpack, anthropic)
#   v8unpack    — e8tools/v8unpack.exe (бинарная распаковка .cfe, шаг 1 для saby)
#   oscript     — OneScript ZIP (запуск tasks/*.os)
#   bsl-ls      — BSL Language Server JAR + Temurin JRE 21 (синтаксконтроль)

param(
    [string]$Tool = "all"   # all | python | v8unpack | oscript | bsl-ls
)

$ErrorActionPreference = "Stop"
$ToolsDir = $PSScriptRoot
$Headers  = @{ "User-Agent" = "1c-extension-ecosystem/get-tools" }

# ── Вспомогательные функции ────────────────────────────────────────

function Write-Step([string]$Msg) {
    Write-Host ""
    Write-Host "▶ $Msg" -ForegroundColor Cyan
}

function Write-OK([string]$Msg) {
    Write-Host "  ✓ $Msg" -ForegroundColor Green
}

function Write-Skip([string]$Msg) {
    Write-Host "  · $Msg (уже установлен)" -ForegroundColor Gray
}

function Write-Fail([string]$Msg) {
    Write-Host "  ✗ $Msg" -ForegroundColor Red
}

function Get-GitHubLatestAsset([string]$Repo, [string]$AssetPattern) {
    $ApiUrl  = "https://api.github.com/repos/$Repo/releases/latest"
    $Release = Invoke-RestMethod -Uri $ApiUrl -Headers $Headers -TimeoutSec 20
    $Asset   = $Release.assets | Where-Object { $_.name -like $AssetPattern } | Select-Object -First 1
    if (-not $Asset) { throw "Актив '$AssetPattern' не найден в релизе $Repo" }
    return @{ Url = $Asset.browser_download_url; Version = $Release.tag_name }
}

function Expand-ZipTo([string]$ZipPath, [string]$Dest) {
    if (Test-Path $Dest) { Remove-Item $Dest -Recurse -Force }
    Expand-Archive -Path $ZipPath -DestinationPath $Dest -Force
}

function Download-File([string]$Url, [string]$OutPath) {
    Invoke-WebRequest -Uri $Url -OutFile $OutPath -Headers $Headers -TimeoutSec 120
}

# ══════════════════════════════════════════════════════════════════
# ИНСТРУМЕНТ 1: Python 3.12 embeddable
# ══════════════════════════════════════════════════════════════════
function Install-Python {
    Write-Step "Python 3.12 embeddable"

    $PythonDir = Join-Path $ToolsDir "python"
    $PythonExe = Join-Path $PythonDir "python.exe"

    if (Test-Path $PythonExe) {
        Write-Skip "tools/python/python.exe"
    } else {
        # Версия зафиксирована — embeddable zip существует для 3.12.x
        $PythonVer = "3.12.10"
        $ZipUrl    = "https://www.python.org/ftp/python/$PythonVer/python-$PythonVer-embed-amd64.zip"
        $ZipPath   = Join-Path $env:TEMP "python-embed.zip"

        Write-Host "  Загрузка Python $PythonVer embeddable..."
        Download-File $ZipUrl $ZipPath
        Expand-ZipTo $ZipPath $PythonDir
        Remove-Item $ZipPath -Force

        # ── Настройка embeddable для pip ──────────────────────────
        # 1. Переименовать ._pth → .pth, раскомментировать import site
        $PthFile = Get-ChildItem $PythonDir -Filter "python312._pth" | Select-Object -First 1
        if ($PthFile) {
            $Content = Get-Content $PthFile.FullName -Raw
            $Content = $Content -replace "#import site", "import site"
            $Content = $Content + "`n.`n.\Lib`n.\Lib\site-packages`n.\Scripts"
            $NewPth  = $PthFile.FullName -replace "_pth$", ".pth"
            Set-Content -Path $NewPth -Value $Content
            # Оставляем оригинальный ._pth — python его всё равно не читает после .pth
        }

        # 2. Создать папку DLLs (нужна для некоторых пакетов)
        $DllsDir = Join-Path $PythonDir "DLLs"
        if (-not (Test-Path $DllsDir)) { New-Item -ItemType Directory $DllsDir | Out-Null }

        # 3. Установить pip через get-pip.py
        Write-Host "  Установка pip..."
        $GetPipPath = Join-Path $env:TEMP "get-pip.py"
        Download-File "https://bootstrap.pypa.io/get-pip.py" $GetPipPath
        & $PythonExe $GetPipPath --quiet
        Remove-Item $GetPipPath -Force

        Write-OK "Python $PythonVer → tools/python/"
    }

    # ── Установка Python-пакетов ──────────────────────────────────
    $PipExe = Join-Path $PythonDir "Scripts\pip.exe"

    # saby v8unpack — полный pipeline .cfe → BSL+JSON
    $V8UnpackPkg = Join-Path $PythonDir "Lib\site-packages\v8unpack"
    if (Test-Path $V8UnpackPkg) {
        Write-Skip "v8unpack (saby)"
    } else {
        Write-Host "  Установка v8unpack (saby-integration)..."
        & $PipExe install v8unpack --quiet
        Write-OK "v8unpack → tools/python/Lib/site-packages/"
    }

    # anthropic SDK — для scripts/ai_review.py
    $AnthropicPkg = Join-Path $PythonDir "Lib\site-packages\anthropic"
    if (Test-Path $AnthropicPkg) {
        Write-Skip "anthropic SDK"
    } else {
        Write-Host "  Установка anthropic SDK..."
        & $PipExe install anthropic --quiet
        Write-OK "anthropic → tools/python/Lib/site-packages/"
    }
}

# ══════════════════════════════════════════════════════════════════
# ИНСТРУМЕНТ 2: v8unpack.exe (e8tools — шаг 1 для saby)
# ══════════════════════════════════════════════════════════════════
function Install-V8Unpack {
    Write-Step "v8unpack.exe (e8tools)"

    $ExePath = Join-Path $ToolsDir "v8unpack.exe"

    if (Test-Path $ExePath) {
        Write-Skip "tools/v8unpack.exe"
        return
    }

    try {
        $Asset = Get-GitHubLatestAsset "e8tools/v8unpack" "v8unpack.exe"
        Write-Host "  Версия: $($Asset.Version)"
        Download-File $Asset.Url $ExePath
        Write-OK "v8unpack.exe $($Asset.Version) → tools/"
    } catch {
        # Fallback на известную версию
        Write-Host "  GitHub API недоступен, загрузка v3.0.43..." -ForegroundColor Yellow
        $FallbackUrl = "https://github.com/e8tools/v8unpack/releases/download/v.3.0.43/v8unpack.exe"
        Download-File $FallbackUrl $ExePath
        Write-OK "v8unpack.exe v3.0.43 → tools/"
    }
}

# ══════════════════════════════════════════════════════════════════
# ИНСТРУМЕНТ 3: OneScript portable (oscript.exe)
# ══════════════════════════════════════════════════════════════════
function Install-OScript {
    Write-Step "OneScript portable (oscript.exe)"

    $OScriptDir = Join-Path $ToolsDir "oscript"
    $OScriptExe = Join-Path $OScriptDir "oscript.exe"

    if (Test-Path $OScriptExe) {
        Write-Skip "tools/oscript/oscript.exe"
        return
    }

    try {
        $Asset = Get-GitHubLatestAsset "EvilBeaver/OneScript" "*win*.zip"
        Write-Host "  Версия: $($Asset.Version)"
        $ZipPath = Join-Path $env:TEMP "oscript.zip"
        Download-File $Asset.Url $ZipPath
        Expand-ZipTo $ZipPath $OScriptDir
        Remove-Item $ZipPath -Force

        # OneScript может распаковаться в подпапку — поднимаем наверх
        $SubDir = Get-ChildItem $OScriptDir -Directory | Select-Object -First 1
        if ($SubDir -and (Test-Path (Join-Path $SubDir.FullName "oscript.exe"))) {
            Get-ChildItem $SubDir.FullName | Move-Item -Destination $OScriptDir
            Remove-Item $SubDir.FullName -Recurse -Force
        }

        Write-OK "oscript $($Asset.Version) → tools/oscript/"
    } catch {
        Write-Fail "Ошибка загрузки OneScript: $_"
        Write-Host "  Скачайте вручную: https://github.com/EvilBeaver/OneScript/releases" -ForegroundColor Yellow
        Write-Host "  Распакуйте в: tools/oscript/"
    }
}

# ══════════════════════════════════════════════════════════════════
# ИНСТРУМЕНТ 4: BSL Language Server + Temurin JRE 21
# ══════════════════════════════════════════════════════════════════
function Install-BslLs {
    Write-Step "BSL Language Server + Temurin JRE 21"

    $BslJar = Join-Path $ToolsDir "bsl-ls.jar"
    $JreDir = Join-Path $ToolsDir "jre"
    $JavaExe = Join-Path $JreDir "bin\java.exe"

    # BSL Language Server JAR
    if (Test-Path $BslJar) {
        Write-Skip "tools/bsl-ls.jar"
    } else {
        try {
            $Asset = Get-GitHubLatestAsset "1c-syntax/bsl-language-server" "*.jar"
            Write-Host "  BSL LS версия: $($Asset.Version)"
            Download-File $Asset.Url $BslJar
            Write-OK "bsl-ls.jar $($Asset.Version) → tools/"
        } catch {
            Write-Fail "Ошибка загрузки BSL LS: $_"
            Write-Host "  Скачайте вручную: https://github.com/1c-syntax/bsl-language-server/releases" -ForegroundColor Yellow
        }
    }

    # Temurin JRE 21 (нужен для запуска bsl-ls.jar)
    if (Test-Path $JavaExe) {
        Write-Skip "tools/jre/bin/java.exe"
    } else {
        Write-Host "  Загрузка Temurin JRE 21 через Adoptium API..."
        try {
            $ApiUrl = "https://api.adoptium.net/v3/assets/latest/21/jre?os=windows&architecture=x64&image_type=jre"
            $Assets = Invoke-RestMethod -Uri $ApiUrl -Headers $Headers -TimeoutSec 20
            $Pkg    = $Assets | Where-Object { $_.binary.package.name -like "*.zip" } | Select-Object -First 1
            $ZipUrl = $Pkg.binary.package.link
            $JreVer = $Pkg.version.semver

            Write-Host "  JRE версия: $JreVer"
            $ZipPath = Join-Path $env:TEMP "temurin-jre.zip"
            Download-File $ZipUrl $ZipPath

            if (-not (Test-Path $JreDir)) { New-Item -ItemType Directory $JreDir | Out-Null }
            Expand-Archive -Path $ZipPath -DestinationPath $JreDir -Force
            Remove-Item $ZipPath -Force

            # JRE распаковывается в подпапку jdk-21.x.x+x — поднимаем наверх
            $SubDir = Get-ChildItem $JreDir -Directory | Select-Object -First 1
            if ($SubDir -and (Test-Path (Join-Path $SubDir.FullName "bin\java.exe"))) {
                Get-ChildItem $SubDir.FullName | Move-Item -Destination $JreDir
                Remove-Item $SubDir.FullName -Recurse -Force
            }

            Write-OK "Temurin JRE $JreVer → tools/jre/"
        } catch {
            Write-Fail "Ошибка загрузки JRE: $_"
            Write-Host "  Скачайте вручную: https://adoptium.net/temurin/releases/?version=21&os=windows&arch=x64&package=jre" -ForegroundColor Yellow
            Write-Host "  Распакуйте в: tools/jre/ (так чтобы был tools/jre/bin/java.exe)"
        }
    }
}

# ══════════════════════════════════════════════════════════════════
# ИТОГОВАЯ ПРОВЕРКА
# ══════════════════════════════════════════════════════════════════
function Show-Summary {
    Write-Host ""
    Write-Host "══════════════════════════════════════════" -ForegroundColor DarkGray
    Write-Host "  Статус инструментов"                     -ForegroundColor White
    Write-Host "══════════════════════════════════════════" -ForegroundColor DarkGray

    $Checks = @(
        @{ Name = "Python 3.12";          Path = "python\python.exe"      },
        @{ Name = "pip";                  Path = "python\Scripts\pip.exe"  },
        @{ Name = "saby v8unpack";        Path = "python\Lib\site-packages\v8unpack" },
        @{ Name = "anthropic SDK";        Path = "python\Lib\site-packages\anthropic" },
        @{ Name = "v8unpack.exe";         Path = "v8unpack.exe"            },
        @{ Name = "oscript.exe";          Path = "oscript\oscript.exe"     },
        @{ Name = "bsl-ls.jar";           Path = "bsl-ls.jar"              },
        @{ Name = "Temurin JRE 21";       Path = "jre\bin\java.exe"        }
    )

    foreach ($c in $Checks) {
        $FullPath = Join-Path $ToolsDir $c.Path
        if (Test-Path $FullPath) {
            Write-Host ("  ✓ {0,-22} tools\{1}" -f $c.Name, $c.Path) -ForegroundColor Green
        } else {
            Write-Host ("  ✗ {0,-22} tools\{1}" -f $c.Name, $c.Path) -ForegroundColor Red
        }
    }

    Write-Host ""
}

# ══════════════════════════════════════════════════════════════════
# ТОЧКА ВХОДА
# ══════════════════════════════════════════════════════════════════
Write-Host ""
Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  1C Extension Ecosystem — get-tools.ps1  ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan

switch ($Tool.ToLower()) {
    "python"   { Install-Python   }
    "v8unpack" { Install-V8Unpack }
    "oscript"  { Install-OScript  }
    "bsl-ls"   { Install-BslLs    }
    "all" {
        Install-Python
        Install-V8Unpack
        Install-OScript
        Install-BslLs
    }
    default {
        Write-Host "Неизвестный инструмент: $Tool" -ForegroundColor Red
        Write-Host "Доступные значения: all | python | v8unpack | oscript | bsl-ls"
        exit 1
    }
}

Show-Summary
