\xEF\xBB\xBF# tools/get-tools.ps1
# Auto-install portable PM tools into tools/ folder (no admin rights required)
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File tools/get-tools.ps1
#   powershell -ExecutionPolicy Bypass -File tools/get-tools.ps1 -Tool python
#
# Tools installed:
#   python    - Python 3.12 embeddable + pip + packages (v8unpack, anthropic)
#   v8unpack  - e8tools/v8unpack.exe (step 1 of .cfe unpack pipeline)
#   oscript   - OneScript portable ZIP (runs tasks/*.os)
#   bsl-ls    - BSL Language Server JAR + Temurin JRE 21 (syntax check)

param(
    [string]$Tool = "all"
)

$ErrorActionPreference = "Stop"
$ToolsDir = $PSScriptRoot
$Headers  = @{ "User-Agent" = "1c-extension-ecosystem/get-tools" }

# -- Helpers ----------------------------------------------------------

function Write-Step([string]$Msg) {
    Write-Host ""
    Write-Host "> $Msg" -ForegroundColor Cyan
}

function Write-OK([string]$Msg) {
    Write-Host "  OK: $Msg" -ForegroundColor Green
}

function Write-Skip([string]$Msg) {
    Write-Host "  SKIP: $Msg (already installed)" -ForegroundColor Gray
}

function Write-Fail([string]$Msg) {
    Write-Host "  FAIL: $Msg" -ForegroundColor Red
}

function Get-GitHubLatestAsset([string]$Repo, [string]$AssetPattern) {
    $ApiUrl  = "https://api.github.com/repos/$Repo/releases/latest"
    $Release = Invoke-RestMethod -Uri $ApiUrl -Headers $Headers -TimeoutSec 20
    $Asset   = $Release.assets | Where-Object { $_.name -like $AssetPattern } | Select-Object -First 1
    if (-not $Asset) { throw "Asset '$AssetPattern' not found in $Repo release" }
    return @{ Url = $Asset.browser_download_url; Version = $Release.tag_name }
}

function Expand-ZipTo([string]$ZipPath, [string]$Dest) {
    if (Test-Path $Dest) { Remove-Item $Dest -Recurse -Force }
    Expand-Archive -Path $ZipPath -DestinationPath $Dest -Force
}

function Download-File([string]$Url, [string]$OutPath) {
    Invoke-WebRequest -Uri $Url -OutFile $OutPath -Headers $Headers -TimeoutSec 120
}

# ==================================================================
# TOOL 1: Python 3.12 embeddable
# ==================================================================
function Install-Python {
    Write-Step "Python 3.12 embeddable"

    $PythonDir = Join-Path $ToolsDir "python"
    $PythonExe = Join-Path $PythonDir "python.exe"

    if (Test-Path $PythonExe) {
        Write-Skip "tools/python/python.exe"
    } else {
        $PythonVer = "3.12.10"
        $ZipUrl    = "https://www.python.org/ftp/python/$PythonVer/python-$PythonVer-embed-amd64.zip"
        $ZipPath   = Join-Path $env:TEMP "python-embed.zip"

        Write-Host "  Downloading Python $PythonVer embeddable..."
        Download-File $ZipUrl $ZipPath
        Expand-ZipTo $ZipPath $PythonDir
        Remove-Item $ZipPath -Force

        # Enable pip: rename ._pth to .pth and uncomment "import site"
        $PthFile = Get-ChildItem $PythonDir -Filter "python312._pth" | Select-Object -First 1
        if ($PthFile) {
            $Content = Get-Content $PthFile.FullName -Raw
            $Content = $Content -replace "#import site", "import site"
            $Content = $Content + "`n.`n.\Lib`n.\Lib\site-packages`n.\Scripts"
            $NewPth  = $PthFile.FullName -replace "_pth$", ".pth"
            Set-Content -Path $NewPth -Value $Content -Encoding UTF8
        }

        # Create DLLs folder (required by some packages)
        $DllsDir = Join-Path $PythonDir "DLLs"
        if (-not (Test-Path $DllsDir)) { New-Item -ItemType Directory $DllsDir | Out-Null }

        # Install pip
        Write-Host "  Installing pip..."
        $GetPipPath = Join-Path $env:TEMP "get-pip.py"
        Download-File "https://bootstrap.pypa.io/get-pip.py" $GetPipPath
        & $PythonExe $GetPipPath --quiet
        Remove-Item $GetPipPath -Force

        Write-OK "Python $PythonVer -> tools/python/"
    }

    $PipExe = Join-Path $PythonDir "Scripts\pip.exe"

    # saby v8unpack - full .cfe -> BSL pipeline
    $V8UnpackPkg = Join-Path $PythonDir "Lib\site-packages\v8unpack"
    if (Test-Path $V8UnpackPkg) {
        Write-Skip "v8unpack (saby)"
    } else {
        Write-Host "  Installing v8unpack (saby-integration)..."
        & $PipExe install v8unpack --quiet
        Write-OK "v8unpack -> tools/python/Lib/site-packages/"
    }

    # anthropic SDK - for scripts/ai_review.py
    $AnthropicPkg = Join-Path $PythonDir "Lib\site-packages\anthropic"
    if (Test-Path $AnthropicPkg) {
        Write-Skip "anthropic SDK"
    } else {
        Write-Host "  Installing anthropic SDK..."
        & $PipExe install anthropic --quiet
        Write-OK "anthropic -> tools/python/Lib/site-packages/"
    }
}

# ==================================================================
# TOOL 2: v8unpack.exe (e8tools - step 1 for saby pipeline)
# ==================================================================
function Install-V8Unpack {
    Write-Step "v8unpack.exe (e8tools)"

    $ExePath = Join-Path $ToolsDir "v8unpack.exe"

    if (Test-Path $ExePath) {
        Write-Skip "tools/v8unpack.exe"
        return
    }

    try {
        $Asset = Get-GitHubLatestAsset "e8tools/v8unpack" "v8unpack.exe"
        Write-Host "  Version: $($Asset.Version)"
        Download-File $Asset.Url $ExePath
        Write-OK "v8unpack.exe $($Asset.Version) -> tools/"
    } catch {
        Write-Host "  GitHub API unavailable, using fallback v3.0.43..." -ForegroundColor Yellow
        $FallbackUrl = "https://github.com/e8tools/v8unpack/releases/download/v.3.0.43/v8unpack.exe"
        Download-File $FallbackUrl $ExePath
        Write-OK "v8unpack.exe v3.0.43 -> tools/"
    }
}

# ==================================================================
# TOOL 3: OneScript portable (oscript.exe)
# ==================================================================
function Install-OScript {
    Write-Step "OneScript portable (oscript.exe)"

    $OScriptDir = Join-Path $ToolsDir "oscript"
    $OScriptExe = Join-Path $OScriptDir "oscript.exe"

    if (Test-Path $OScriptExe) {
        Write-Skip "tools/oscript/oscript.exe"
        return
    }

    try {
        $Asset = Get-GitHubLatestAsset "EvilBeaver/OneScript" "*win*.zip"
        Write-Host "  Version: $($Asset.Version)"
        $ZipPath = Join-Path $env:TEMP "oscript.zip"
        Download-File $Asset.Url $ZipPath
        Expand-ZipTo $ZipPath $OScriptDir
        Remove-Item $ZipPath -Force

        # Flatten if extracted into subfolder
        $SubDir = Get-ChildItem $OScriptDir -Directory | Select-Object -First 1
        if ($SubDir -and (Test-Path (Join-Path $SubDir.FullName "oscript.exe"))) {
            Get-ChildItem $SubDir.FullName | Move-Item -Destination $OScriptDir
            Remove-Item $SubDir.FullName -Recurse -Force
        }

        Write-OK "oscript $($Asset.Version) -> tools/oscript/"
    } catch {
        Write-Fail "OneScript download error: $_"
        Write-Host "  Download manually: https://github.com/EvilBeaver/OneScript/releases" -ForegroundColor Yellow
        Write-Host "  Extract to: tools/oscript/"
    }
}

# ==================================================================
# TOOL 4: BSL Language Server + Temurin JRE 21
# ==================================================================
function Install-BslLs {
    Write-Step "BSL Language Server + Temurin JRE 21"

    $BslJar = Join-Path $ToolsDir "bsl-ls.jar"
    $JreDir = Join-Path $ToolsDir "jre"
    $JavaExe = Join-Path $JreDir "bin\java.exe"

    if (Test-Path $BslJar) {
        Write-Skip "tools/bsl-ls.jar"
    } else {
        try {
            $Asset = Get-GitHubLatestAsset "1c-syntax/bsl-language-server" "*.jar"
            Write-Host "  BSL LS version: $($Asset.Version)"
            Download-File $Asset.Url $BslJar
            Write-OK "bsl-ls.jar $($Asset.Version) -> tools/"
        } catch {
            Write-Fail "BSL LS download error: $_"
            Write-Host "  Download manually: https://github.com/1c-syntax/bsl-language-server/releases" -ForegroundColor Yellow
        }
    }

    if (Test-Path $JavaExe) {
        Write-Skip "tools/jre/bin/java.exe"
    } else {
        Write-Host "  Downloading Temurin JRE 21 via Adoptium API..."
        try {
            $ApiUrl = "https://api.adoptium.net/v3/assets/latest/21/jre?os=windows&architecture=x64&image_type=jre"
            $Assets = Invoke-RestMethod -Uri $ApiUrl -Headers $Headers -TimeoutSec 20
            $Pkg    = $Assets | Where-Object { $_.binary.package.name -like "*.zip" } | Select-Object -First 1
            $ZipUrl = $Pkg.binary.package.link
            $JreVer = $Pkg.version.semver

            Write-Host "  JRE version: $JreVer"
            $ZipPath = Join-Path $env:TEMP "temurin-jre.zip"
            Download-File $ZipUrl $ZipPath

            if (-not (Test-Path $JreDir)) { New-Item -ItemType Directory $JreDir | Out-Null }
            Expand-Archive -Path $ZipPath -DestinationPath $JreDir -Force
            Remove-Item $ZipPath -Force

            # Flatten if extracted into subfolder
            $SubDir = Get-ChildItem $JreDir -Directory | Select-Object -First 1
            if ($SubDir -and (Test-Path (Join-Path $SubDir.FullName "bin\java.exe"))) {
                Get-ChildItem $SubDir.FullName | Move-Item -Destination $JreDir
                Remove-Item $SubDir.FullName -Recurse -Force
            }

            Write-OK "Temurin JRE $JreVer -> tools/jre/"
        } catch {
            Write-Fail "JRE download error: $_"
            Write-Host "  Download manually: https://adoptium.net/temurin/releases/?version=21&os=windows&arch=x64&package=jre" -ForegroundColor Yellow
            Write-Host "  Extract to: tools/jre/ (so that tools/jre/bin/java.exe exists)"
        }
    }
}

# ==================================================================
# SUMMARY
# ==================================================================
function Show-Summary {
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor DarkGray
    Write-Host "  Tools status"                             -ForegroundColor White
    Write-Host "==========================================" -ForegroundColor DarkGray

    $Checks = @(
        @{ Name = "Python 3.12";     Path = "python\python.exe"                       },
        @{ Name = "pip";             Path = "python\Scripts\pip.exe"                  },
        @{ Name = "saby v8unpack";   Path = "python\Lib\site-packages\v8unpack"       },
        @{ Name = "anthropic SDK";   Path = "python\Lib\site-packages\anthropic"      },
        @{ Name = "v8unpack.exe";    Path = "v8unpack.exe"                            },
        @{ Name = "oscript.exe";     Path = "oscript\oscript.exe"                     },
        @{ Name = "bsl-ls.jar";      Path = "bsl-ls.jar"                              },
        @{ Name = "Temurin JRE 21";  Path = "jre\bin\java.exe"                        }
    )

    foreach ($c in $Checks) {
        $FullPath = Join-Path $ToolsDir $c.Path
        $Status   = if (Test-Path $FullPath) { "OK  " } else { "MISS" }
        $Color    = if (Test-Path $FullPath) { "Green" } else { "Red" }
        Write-Host ("  [{0}] {1,-22} tools\{2}" -f $Status, $c.Name, $c.Path) -ForegroundColor $Color
    }

    Write-Host ""
}

# ==================================================================
# ENTRY POINT
# ==================================================================
Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  1C Extension Ecosystem - get-tools.ps1"   -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

switch ($Tool.ToLower()) {
    "python"   { Install-Python   }
    "v8unpack" { Install-V8Unpack }
    "oscript"  { Install-OScript  }
    "bsl-ls"   { Install-BslLs    }
    "all" {
        Install-Python
        Install-V8Unpack
        Install-OScript
        Install-BslLs
    }
    default {
        Write-Host "Unknown tool: $Tool" -ForegroundColor Red
        Write-Host "Available values: all | python | v8unpack | oscript | bsl-ls"
        exit 1
    }
}

Show-Summary
