# tools/get-tools.ps1
# Auto-install portable PM tools into tools/ folder (no admin rights required)
#
# Usage (from project folder):
#   powershell -ExecutionPolicy Bypass -File tools/get-tools.ps1
#   powershell -ExecutionPolicy Bypass -File tools/get-tools.ps1 -Tool python
#
# Tools: python | v8unpack | oscript | bsl-ls | all
# Log:   tools/logs/get-tools.log

param(
    [string]$Tool = "all"
)

$ErrorActionPreference = "Stop"
$ToolsDir = $PSScriptRoot
$Headers  = @{ "User-Agent" = "1c-extension-ecosystem/get-tools" }
$LogDir   = Join-Path $ToolsDir "logs"
$LogFile  = Join-Path $LogDir "get-tools.log"

# -- Logging ----------------------------------------------------------

function Write-Log([string]$Level, [string]$Msg) {
    $Stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $Line  = "[$Stamp] [$Level] $Msg"
    # ???????
    switch ($Level) {
        "INFO"  { Write-Host "  $Msg" -ForegroundColor Gray }
        "OK"    { Write-Host "  OK: $Msg" -ForegroundColor Green }
        "SKIP"  { Write-Host "  SKIP: $Msg (already installed)" -ForegroundColor Gray }
        "FAIL"  { Write-Host "  FAIL: $Msg" -ForegroundColor Red }
        "STEP"  { Write-Host ""; Write-Host "> $Msg" -ForegroundColor Cyan }
        "ERROR" { Write-Host "  ERROR: $Msg" -ForegroundColor Red }
    }
    # ????
    try {
        if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory $LogDir -Force | Out-Null }
        Add-Content -Path $LogFile -Value $Line -Encoding UTF8
    } catch { }
}

function Write-Step([string]$Msg)  { Write-Log "STEP"  $Msg }
function Write-OK([string]$Msg)    { Write-Log "OK"    $Msg }
function Write-Skip([string]$Msg)  { Write-Log "SKIP"  $Msg }
function Write-Fail([string]$Msg)  { Write-Log "FAIL"  $Msg }
function Write-Info([string]$Msg)  { Write-Log "INFO"  $Msg }

function Write-LogError([string]$Msg) {
    Write-Log "ERROR" $Msg
}

function Download-File([string]$Url, [string]$OutPath) {
    Write-Info "Downloading: $Url"
    try {
        Invoke-WebRequest -Uri $Url -OutFile $OutPath -Headers $Headers -TimeoutSec 120
    } catch {
        Write-LogError "Download failed: $Url ? $_"
        throw
    }
}

function Get-GitHubLatestAsset([string]$Repo, [string]$AssetPattern) {
    $ApiUrl  = "https://api.github.com/repos/$Repo/releases/latest"
    $Release = Invoke-RestMethod -Uri $ApiUrl -Headers $Headers -TimeoutSec 20
    $Asset   = $Release.assets | Where-Object { $_.name -like $AssetPattern } | Select-Object -First 1
    if (-not $Asset) { throw "Asset '$AssetPattern' not found in $Repo" }
    return @{ Url = $Asset.browser_download_url; Version = $Release.tag_name }
}

function Expand-ZipTo([string]$ZipPath, [string]$Dest) {
    if (Test-Path $Dest) { Remove-Item $Dest -Recurse -Force }
    Expand-Archive -Path $ZipPath -DestinationPath $Dest -Force
}

# ==================================================================
# TOOL 1: Python 3.12 embeddable
# ==================================================================
function Install-Python {
    Write-Step "Python 3.12 embeddable"

    $PythonDir = Join-Path $ToolsDir "python"
    $PythonExe = Join-Path $PythonDir "python.exe"
    $PipExe    = Join-Path $PythonDir "Scripts\pip.exe"

    if (-not (Test-Path $PythonExe)) {
        $PythonVer = "3.12.10"
        $ZipUrl    = "https://www.python.org/ftp/python/$PythonVer/python-$PythonVer-embed-amd64.zip"
        $ZipPath   = Join-Path $env:TEMP "python-embed.zip"

        Write-Host "  Downloading Python $PythonVer embeddable..."
        Download-File $ZipUrl $ZipPath
        Expand-ZipTo $ZipPath $PythonDir
        Remove-Item $ZipPath -Force

        # Fix embeddable Python to support pip:
        # 1. Find and edit the ._pth file to uncomment "import site"
        $PthFile = Get-ChildItem $PythonDir -Filter "python*._pth" | Select-Object -First 1
        if ($PthFile) {
            $Lines = Get-Content $PthFile.FullName
            $Lines = $Lines | ForEach-Object { $_ -replace "^#import site", "import site" }
            Set-Content -Path $PthFile.FullName -Value $Lines
        }

        # 2. Install pip via get-pip.py
        Write-Host "  Installing pip..."
        $GetPipPath = Join-Path $env:TEMP "get-pip.py"
        Download-File "https://bootstrap.pypa.io/get-pip.py" $GetPipPath
        & $PythonExe $GetPipPath --no-warn-script-location --quiet
        Remove-Item $GetPipPath -Force

        Write-OK "Python $PythonVer -> tools/python/"
    } else {
        Write-Skip "tools/python/python.exe"
    }

    # Verify pip works
    $PipTest = & $PythonExe -m pip --version 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Fail "pip not working: $PipTest"
        return
    }

    # saby v8unpack
    $V8Pkg = Join-Path $PythonDir "Lib\site-packages\v8unpack"
    if (Test-Path $V8Pkg) {
        Write-Skip "saby v8unpack"
    } else {
        Write-Host "  Installing v8unpack (saby)..."
        & $PythonExe -m pip install v8unpack --no-warn-script-location --quiet
        if ($LASTEXITCODE -eq 0) { Write-OK "v8unpack installed" }
        else { Write-Fail "v8unpack install failed" }
    }

    # anthropic SDK
    $AntPkg = Join-Path $PythonDir "Lib\site-packages\anthropic"
    if (Test-Path $AntPkg) {
        Write-Skip "anthropic SDK"
    } else {
        Write-Host "  Installing anthropic SDK..."
        & $PythonExe -m pip install anthropic --no-warn-script-location --quiet
        if ($LASTEXITCODE -eq 0) { Write-OK "anthropic SDK installed" }
        else { Write-Fail "anthropic SDK install failed" }
    }

    # mcp-server-git ? Git MCP server ??? Claude Code
    $McpGitPkg = Join-Path $PythonDir "Lib\site-packages\mcp_server_git"
    if (Test-Path $McpGitPkg) {
        Write-Skip "mcp-server-git"
    } else {
        Write-Host "  Installing mcp-server-git..."
        & $PythonExe -m pip install mcp-server-git --no-warn-script-location --quiet
        if ($LASTEXITCODE -eq 0) { Write-OK "mcp-server-git installed" }
        else { Write-Fail "mcp-server-git install failed" }
    }
}

# ==================================================================
# TOOL 2: v8unpack.exe (e8tools)
# ==================================================================
function Install-V8Unpack {
    Write-Step "v8unpack.exe (e8tools)"

    $ExePath = Join-Path $ToolsDir "v8unpack.exe"
    if (Test-Path $ExePath) { Write-Skip "tools/v8unpack.exe"; return }

    try {
        $Asset = Get-GitHubLatestAsset "e8tools/v8unpack" "v8unpack.exe"
        Write-Host "  Version: $($Asset.Version)"
        Download-File $Asset.Url $ExePath
        Write-OK "v8unpack.exe $($Asset.Version) -> tools/"
    } catch {
        Write-Host "  GitHub API unavailable, using fallback v3.0.43..." -ForegroundColor Yellow
        Download-File "https://github.com/e8tools/v8unpack/releases/download/v.3.0.43/v8unpack.exe" $ExePath
        Write-OK "v8unpack.exe v3.0.43 -> tools/"
    }
}

# ==================================================================
# TOOL 3: OneScript portable
# ==================================================================
function Install-OScript {
    Write-Step "OneScript portable (oscript.exe)"

    $OScriptDir = Join-Path $ToolsDir "oscript"
    $OScriptExe = Join-Path $OScriptDir "oscript.exe"
    if (Test-Path $OScriptExe) { Write-Skip "tools/oscript/oscript.exe"; return }

    try {
        $Asset   = Get-GitHubLatestAsset "EvilBeaver/OneScript" "*win*.zip"
        Write-Host "  Version: $($Asset.Version)"
        $ZipPath = Join-Path $env:TEMP "oscript.zip"
        Download-File $Asset.Url $ZipPath
        Expand-ZipTo $ZipPath $OScriptDir
        Remove-Item $ZipPath -Force

        # Flatten subfolder if needed
        $SubDir = Get-ChildItem $OScriptDir -Directory | Select-Object -First 1
        if ($SubDir -and (Test-Path (Join-Path $SubDir.FullName "oscript.exe"))) {
            Get-ChildItem $SubDir.FullName | Move-Item -Destination $OScriptDir -Force
            Remove-Item $SubDir.FullName -Recurse -Force
        }
        Write-OK "oscript $($Asset.Version) -> tools/oscript/"
    } catch {
        Write-Fail "OneScript download error: $_"
        Write-Host "  Download manually: https://github.com/EvilBeaver/OneScript/releases" -ForegroundColor Yellow
    }
}

# ==================================================================
# TOOL 4: BSL Language Server + Temurin JRE 21
# ==================================================================
function Install-BslLs {
    Write-Step "BSL Language Server + Temurin JRE 21"

    $BslJar  = Join-Path $ToolsDir "bsl-ls.jar"
    $JreDir  = Join-Path $ToolsDir "jre"
    $JavaExe = Join-Path $JreDir "bin\java.exe"

    # BSL LS JAR
    if (Test-Path $BslJar) {
        Write-Skip "tools/bsl-ls.jar"
    } else {
        try {
            $Asset = Get-GitHubLatestAsset "1c-syntax/bsl-language-server" "*.jar"
            Write-Host "  BSL LS version: $($Asset.Version)"
            Download-File $Asset.Url $BslJar
            Write-OK "bsl-ls.jar $($Asset.Version) -> tools/"
        } catch {
            Write-Fail "BSL LS download error: $_"
            Write-Host "  Download manually: https://github.com/1c-syntax/bsl-language-server/releases" -ForegroundColor Yellow
        }
    }

    # Temurin JRE 21
    if (Test-Path $JavaExe) {
        Write-Skip "tools/jre/bin/java.exe"
    } else {
        Write-Host "  Downloading Temurin JRE 21..."
        try {
            # Use direct API endpoint with explicit feature version
            $ApiUrl = "https://api.adoptium.net/v3/assets/feature_releases/21/ga?os=windows&architecture=x64&image_type=jre&jvm_impl=hotspot&heap_size=normal&page=0&page_size=1&sort_method=DEFAULT&sort_order=DESC&vendor=eclipse"
            $Assets = Invoke-RestMethod -Uri $ApiUrl -Headers $Headers -TimeoutSec 30
            $Pkg    = $Assets[0].binaries[0].package
            $ZipUrl = $Pkg.link
            $JreVer = $Assets[0].version_data.semver

            Write-Host "  JRE version: $JreVer"
            $ZipPath = Join-Path $env:TEMP "temurin-jre.zip"
            Download-File $ZipUrl $ZipPath

            if (-not (Test-Path $JreDir)) { New-Item -ItemType Directory $JreDir | Out-Null }
            Expand-Archive -Path $ZipPath -DestinationPath $JreDir -Force
            Remove-Item $ZipPath -Force

            # Flatten subfolder
            $SubDir = Get-ChildItem $JreDir -Directory | Select-Object -First 1
            if ($SubDir -and (Test-Path (Join-Path $SubDir.FullName "bin\java.exe"))) {
                Get-ChildItem $SubDir.FullName | Move-Item -Destination $JreDir -Force
                Remove-Item $SubDir.FullName -Recurse -Force
            }
            Write-OK "Temurin JRE $JreVer -> tools/jre/"
        } catch {
            Write-Fail "JRE download error: $_"
            Write-Host "  Download manually:" -ForegroundColor Yellow
            Write-Host "  https://adoptium.net/temurin/releases/?version=21&os=windows&arch=x64&package=jre" -ForegroundColor Yellow
            Write-Host "  Extract so that tools/jre/bin/java.exe exists"
        }
    }
}

# ==================================================================
# SUMMARY
# ==================================================================
function Show-Summary {
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor DarkGray
    Write-Host "  Tools status"                             -ForegroundColor White
    Write-Host "==========================================" -ForegroundColor DarkGray

    $Checks = @(
        @{ Name = "Python 3.12";    Path = "python\python.exe"                       },
        @{ Name = "pip";            Path = "python\Scripts\pip.exe"                 },
        @{ Name = "saby v8unpack";  Path = "python\Lib\site-packages\v8unpack"      },
        @{ Name = "anthropic SDK";  Path = "python\Lib\site-packages\anthropic"     },
        @{ Name = "mcp-server-git"; Path = "python\Lib\site-packages\mcp_server_git"},
        @{ Name = "v8unpack.exe";   Path = "v8unpack.exe"                           },
        @{ Name = "oscript.exe";    Path = "oscript\oscript.exe"                    },
        @{ Name = "bsl-ls.jar";     Path = "bsl-ls.jar"                             },
        @{ Name = "Temurin JRE 21"; Path = "jre\bin\java.exe"                       }
    )

    foreach ($c in $Checks) {
        $FullPath = Join-Path $ToolsDir $c.Path
        if (Test-Path $FullPath) {
            Write-Host ("  [OK  ] {0,-22} tools\{1}" -f $c.Name, $c.Path) -ForegroundColor Green
        } else {
            Write-Host ("  [MISS] {0,-22} tools\{1}" -f $c.Name, $c.Path) -ForegroundColor Red
        }
    }
    Write-Host ""
}

# ==================================================================
# ENTRY POINT
# ==================================================================
Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  1C Extension Ecosystem - get-tools.ps1"   -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan

Write-Log "INFO" "=== get-tools.ps1 started (Tool: $Tool) ==="

try {
    switch ($Tool.ToLower()) {
        "python"   { Install-Python   }
        "v8unpack" { Install-V8Unpack }
        "oscript"  { Install-OScript  }
        "bsl-ls"   { Install-BslLs    }
        "all" {
            Install-Python
            Install-V8Unpack
            Install-OScript
            Install-BslLs
        }
        default {
            Write-Host "Unknown tool: $Tool" -ForegroundColor Red
            Write-Host "Available: all | python | v8unpack | oscript | bsl-ls"
            Write-LogError "Unknown tool: $Tool"
            exit 1
        }
    }
    Write-Log "INFO" "=== get-tools.ps1 completed successfully ==="
} catch {
    Write-LogError "=== get-tools.ps1 FAILED: $_ ==="
    Write-Host ""
    Write-Host "  See log: $LogFile" -ForegroundColor Yellow
    throw
}

Show-Summary
Write-Log "INFO" "Log: $LogFile"
