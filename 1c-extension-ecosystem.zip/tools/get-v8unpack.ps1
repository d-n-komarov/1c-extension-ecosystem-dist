# tools/get-v8unpack.ps1
# Загрузка e8tools/v8unpack.exe (шаг 1 pipeline — бинарная распаковка)
# ВНИМАНИЕ: e8tools/v8unpack даёт только бинарные блоки, не читаемый BSL/JSON.
# Для полного pipeline используйте tasks/unpack.os (выбор метода автоматически).
#
# Запуск напрямую: pwsh -File tools/get-v8unpack.ps1

$ToolsDir    = Join-Path $PSScriptRoot ""
$ExePath     = Join-Path $ToolsDir "v8unpack.exe"
$ApiUrl      = "https://api.github.com/repos/e8tools/v8unpack/releases/latest"
$FallbackUrl = "https://github.com/e8tools/v8unpack/releases/download/v.3.0.43/v8unpack.exe"

if (Test-Path $ExePath) {
    Write-Host "v8unpack.exe уже есть: $ExePath" -ForegroundColor Green
    exit 0
}

Write-Host "Загрузка v8unpack.exe (e8tools) из GitHub..." -ForegroundColor Cyan

try {
    $headers = @{ "User-Agent" = "1c-extension-ecosystem" }
    $release = Invoke-RestMethod -Uri $ApiUrl -Headers $headers -TimeoutSec 15
    $asset   = $release.assets | Where-Object { $_.name -eq "v8unpack.exe" } | Select-Object -First 1
    $DownloadUrl = if ($asset) { $asset.browser_download_url } else { $FallbackUrl }
    Write-Host "Версия: $($release.tag_name)" -ForegroundColor Gray
} catch {
    Write-Host "GitHub API недоступен, fallback на v3.0.43" -ForegroundColor Yellow
    $DownloadUrl = $FallbackUrl
}

try {
    Invoke-WebRequest -Uri $DownloadUrl -OutFile $ExePath -TimeoutSec 60
    $size = (Get-Item $ExePath).Length / 1KB
    Write-Host ("OK: v8unpack.exe загружен ({0:N0} KB)" -f $size) -ForegroundColor Green
} catch {
    Write-Host "ОШИБКА: $_" -ForegroundColor Red
    Write-Host "Скачайте вручную: $FallbackUrl" -ForegroundColor Yellow
    Write-Host "Положите в: $ExePath"
    exit 1
}
